﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace atms
{
    public partial class InsertCard : Form
    {
        public InsertCard()
        {
            InitializeComponent();
        }

        private void HScrollBar_Scroll(object sender, ScrollEventArgs e)
        {
            HScrollBar.Minimum = 0;
            HScrollBar.Maximum = 100;

            if (HScrollBar.Value == 100)
            {
                label5.Text = HScrollBar.Value.ToString() + "%";
                label6.Visible = true;
                groupBox1.Enabled = true;
                CardPin.Visible = true;
            }
            else if (HScrollBar.Value != 100)
            {
                label5.Text = HScrollBar.Value.ToString();

            }
        }

        private void InsertCard_Load(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;
            CardPin.Visible = false;
        }

        private void enter_Click(object sender, EventArgs e)
        {
            string pin = "0608";



            if (CardPin.Text == pin)
            {
                string box_msg = "Log In Successfully!";
                MessageBox.Show(box_msg, "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                this.Hide();
               MenuForm f3 = new MenuForm();
                f3.ShowDialog();
            }
                if(CardPin.Text != pin)
            {
                string box_msg = "Invalid PIN! Please try again \n  Attempts: " + x + " out of 3";
                MessageBox.Show(box_msg, "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                x++;
                CardPin.Text = "";

                 
                if (x == 4)
                {
                    string box_msg1 = "Sorry your account is block!";
                    MessageBox.Show(box_msg1, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    this.Hide();
                    Form1 form = new Form1();
                    form.ShowDialog();
                }


            }
        }

        private void clear_Click(object sender, EventArgs e)
        {
           CardPin.Clear();
        }

        int x = 1;


        private void one_Click(object sender, EventArgs e)
        {
            int number = 1;
            CardPin.Text += number;
        }

        private void two_Click(object sender, EventArgs e)
        {
            int number = 2;
            CardPin.Text += number;
        }

        private void three_Click(object sender, EventArgs e)
        {
            int number = 3;
            CardPin.Text += number;
        }

        private void four_Click(object sender, EventArgs e)
        {
            int number = 4;
            CardPin.Text += number;
        }

        private void five_Click(object sender, EventArgs e)
        {
            int number = 5;
            CardPin.Text += number;
        }

        private void six_Click(object sender, EventArgs e)
        {
            int number = 6;
            CardPin.Text += number;
        }

        private void seven_Click(object sender, EventArgs e)
        {
            int number = 7;
            CardPin.Text += number;
        }

        private void eight_Click(object sender, EventArgs e)
        {
            int number = 8;
            CardPin.Text += number;
        }

        private void nine_Click(object sender, EventArgs e)
        {
            int number = 9;
            CardPin.Text += number;
        }

        private void zero_Click(object sender, EventArgs e)
        {
            int number = 0;
            CardPin.Text += number;
        }
    }
}
