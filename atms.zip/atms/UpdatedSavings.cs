﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atms
{
    public partial class UpdatedSavings : Form
    {
        public UpdatedSavings()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            MenuForm main = new MenuForm();
            main.Show();
        }

        private void UpdatedSavings_Load(object sender, EventArgs e)
        {
            textBox1.Text = GlobalVariable.acountNo_1;
            textBox2.Text = GlobalVariable.current_Bal;
        }
    }
}
