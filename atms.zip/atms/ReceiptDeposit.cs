﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atms
{
    public partial class ReceiptDeposit : Form
    {
        public ReceiptDeposit()
        {
            InitializeComponent();
        }

        private void ReceiptDeposit_Load(object sender, EventArgs e)
        {
             deposit.Text = GlobalVariable.withdraw_1;

            int a = Convert.ToInt32(GlobalVariable.withdraw_1);
            int b = Convert.ToInt32(GlobalVariable.available_Bal);
            int c = b + a;

            acc.Text = GlobalVariable.acountNo_1;

            present.Text = Convert.ToString(c);
            date.Text = "05/16/2023";

            GlobalVariable.current_Bal = Convert.ToString(c);
            GlobalVariable.available_Bal = Convert.ToString(c);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Done_Click(object sender, EventArgs e)
        {

            this.Hide();
            MenuForm main = new MenuForm();
            main.Show();
        }

        private void deposit_Click(object sender, EventArgs e)
        {

        }

        private void withdraw_Click(object sender, EventArgs e)
        {

        }
    }
}
