﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atms
{
    internal class GlobalVariable
    {
        private static string acountNo1 = "0123*****";

        public static string acountNo_1
        {
            get { return acountNo1; }
            set { acountNo1 = value; }
        }

        private static string currentBal = "1000000";

        public static string current_Bal
        {
            get { return currentBal; }
            set { currentBal = value; }
        }

        private static string availableBal = "1000000";

        public static string available_Bal
        {
            get { return availableBal; }
            set { availableBal = value; }
        }

        private static string withdraw = "0";

        public static string withdraw_1
        {
            get { return withdraw; }
            set { withdraw = value; }
        }

        private static string location = "0";

        public static string location_1
        {
            get { return location; }
            set { location = value; }
        }

    }
}
