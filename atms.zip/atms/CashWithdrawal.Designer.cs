﻿namespace atms
{
    partial class CashWithdrawal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CashWithdrawal));
            this.Back = new Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton();
            this.zero = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.nine = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.one = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.eight = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.Withdraw = new Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton();
            this.seven = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.clear = new Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton();
            this.six = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.two = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.five = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.three = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.four = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.label1 = new System.Windows.Forms.Label();
            this.EnterAmount = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Back
            // 
            this.Back.BackColor = System.Drawing.Color.Transparent;
            this.Back.BorderRadius = 8;
            this.Back.BorderThickness = 2;
            this.Back.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Back.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Back.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Back.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Back.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Back.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.Back.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(15)))), ((int)(((byte)(255)))));
            this.Back.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.Back.ForeColor = System.Drawing.Color.White;
            this.Back.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.Back.Location = new System.Drawing.Point(32, 509);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(110, 39);
            this.Back.TabIndex = 228;
            this.Back.Text = "BACK";
            this.Back.UseTransparentBackground = true;
            this.Back.Click += new System.EventHandler(this.Back_Click);
            // 
            // zero
            // 
            this.zero.Animated = true;
            this.zero.BackColor = System.Drawing.Color.Transparent;
            this.zero.BorderRadius = 20;
            this.zero.BorderThickness = 2;
            this.zero.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.zero.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.zero.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.zero.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.zero.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.zero.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.zero.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.zero.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.zero.ForeColor = System.Drawing.Color.Black;
            this.zero.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.zero.Location = new System.Drawing.Point(245, 314);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(70, 45);
            this.zero.TabIndex = 232;
            this.zero.Text = "0";
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // nine
            // 
            this.nine.Animated = true;
            this.nine.BackColor = System.Drawing.Color.Transparent;
            this.nine.BorderRadius = 20;
            this.nine.BorderThickness = 2;
            this.nine.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.nine.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.nine.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.nine.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.nine.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.nine.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.nine.ForeColor = System.Drawing.Color.Black;
            this.nine.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.nine.Location = new System.Drawing.Point(341, 263);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(70, 45);
            this.nine.TabIndex = 231;
            this.nine.Text = "9";
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // one
            // 
            this.one.Animated = true;
            this.one.BackColor = System.Drawing.Color.Transparent;
            this.one.BorderRadius = 20;
            this.one.BorderThickness = 2;
            this.one.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.one.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.one.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.one.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.one.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.one.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.one.ForeColor = System.Drawing.Color.Black;
            this.one.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.one.Location = new System.Drawing.Point(145, 161);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(70, 45);
            this.one.TabIndex = 223;
            this.one.Text = "1";
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.zero);
            this.groupBox1.Controls.Add(this.nine);
            this.groupBox1.Controls.Add(this.one);
            this.groupBox1.Controls.Add(this.eight);
            this.groupBox1.Controls.Add(this.Withdraw);
            this.groupBox1.Controls.Add(this.seven);
            this.groupBox1.Controls.Add(this.clear);
            this.groupBox1.Controls.Add(this.six);
            this.groupBox1.Controls.Add(this.two);
            this.groupBox1.Controls.Add(this.five);
            this.groupBox1.Controls.Add(this.three);
            this.groupBox1.Controls.Add(this.four);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.EnterAmount);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(197, 142);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(548, 406);
            this.groupBox1.TabIndex = 227;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CASH WITHDRAWAL";
            // 
            // eight
            // 
            this.eight.Animated = true;
            this.eight.BackColor = System.Drawing.Color.Transparent;
            this.eight.BorderRadius = 20;
            this.eight.BorderThickness = 2;
            this.eight.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.eight.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.eight.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.eight.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.eight.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.eight.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.eight.ForeColor = System.Drawing.Color.Black;
            this.eight.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.eight.Location = new System.Drawing.Point(245, 263);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(70, 45);
            this.eight.TabIndex = 230;
            this.eight.Text = "8";
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // Withdraw
            // 
            this.Withdraw.BackColor = System.Drawing.Color.Transparent;
            this.Withdraw.BorderRadius = 8;
            this.Withdraw.BorderThickness = 2;
            this.Withdraw.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Withdraw.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Withdraw.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Withdraw.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Withdraw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Withdraw.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.Withdraw.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(15)))), ((int)(((byte)(255)))));
            this.Withdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.Withdraw.ForeColor = System.Drawing.Color.White;
            this.Withdraw.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.Withdraw.Location = new System.Drawing.Point(341, 325);
            this.Withdraw.Name = "Withdraw";
            this.Withdraw.Size = new System.Drawing.Size(114, 39);
            this.Withdraw.TabIndex = 221;
            this.Withdraw.Text = "WITHDRAW";
            this.Withdraw.UseTransparentBackground = true;
            this.Withdraw.Click += new System.EventHandler(this.Withdraw_Click);
            // 
            // seven
            // 
            this.seven.Animated = true;
            this.seven.BackColor = System.Drawing.Color.Transparent;
            this.seven.BorderRadius = 20;
            this.seven.BorderThickness = 2;
            this.seven.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.seven.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.seven.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.seven.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.seven.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.seven.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.seven.ForeColor = System.Drawing.Color.Black;
            this.seven.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.seven.Location = new System.Drawing.Point(145, 263);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(70, 45);
            this.seven.TabIndex = 229;
            this.seven.Text = "7";
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.Color.Transparent;
            this.clear.BorderRadius = 8;
            this.clear.BorderThickness = 2;
            this.clear.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clear.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clear.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clear.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clear.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.clear.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(15)))), ((int)(((byte)(255)))));
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.clear.ForeColor = System.Drawing.Color.White;
            this.clear.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.clear.Location = new System.Drawing.Point(105, 325);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(110, 39);
            this.clear.TabIndex = 222;
            this.clear.Text = "CLEAR";
            this.clear.UseTransparentBackground = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // six
            // 
            this.six.Animated = true;
            this.six.BackColor = System.Drawing.Color.Transparent;
            this.six.BorderRadius = 20;
            this.six.BorderThickness = 2;
            this.six.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.six.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.six.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.six.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.six.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.six.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.six.ForeColor = System.Drawing.Color.Black;
            this.six.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.six.Location = new System.Drawing.Point(341, 212);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(70, 45);
            this.six.TabIndex = 228;
            this.six.Text = "6";
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // two
            // 
            this.two.Animated = true;
            this.two.BackColor = System.Drawing.Color.Transparent;
            this.two.BorderRadius = 20;
            this.two.BorderThickness = 2;
            this.two.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.two.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.two.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.two.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.two.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.two.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.two.ForeColor = System.Drawing.Color.Black;
            this.two.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.two.Location = new System.Drawing.Point(245, 161);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(70, 45);
            this.two.TabIndex = 224;
            this.two.Text = "2";
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // five
            // 
            this.five.Animated = true;
            this.five.BackColor = System.Drawing.Color.Transparent;
            this.five.BorderRadius = 20;
            this.five.BorderThickness = 2;
            this.five.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.five.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.five.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.five.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.five.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.five.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.five.ForeColor = System.Drawing.Color.Black;
            this.five.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.five.Location = new System.Drawing.Point(245, 212);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(70, 45);
            this.five.TabIndex = 227;
            this.five.Text = "5";
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // three
            // 
            this.three.Animated = true;
            this.three.BackColor = System.Drawing.Color.Transparent;
            this.three.BorderRadius = 20;
            this.three.BorderThickness = 2;
            this.three.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.three.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.three.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.three.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.three.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.three.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.three.ForeColor = System.Drawing.Color.Black;
            this.three.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.three.Location = new System.Drawing.Point(341, 161);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(70, 45);
            this.three.TabIndex = 225;
            this.three.Text = "3";
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // four
            // 
            this.four.Animated = true;
            this.four.BackColor = System.Drawing.Color.Transparent;
            this.four.BorderRadius = 20;
            this.four.BorderThickness = 2;
            this.four.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.four.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.four.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.four.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.four.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.four.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.four.ForeColor = System.Drawing.Color.Black;
            this.four.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.four.Location = new System.Drawing.Point(145, 212);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(70, 45);
            this.four.TabIndex = 226;
            this.four.Text = "4";
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 16);
            this.label1.TabIndex = 220;
            this.label1.Text = "ENTER AMOUNT:";
            // 
            // EnterAmount
            // 
            this.EnterAmount.BorderRadius = 18;
            this.EnterAmount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.EnterAmount.DefaultText = "";
            this.EnterAmount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.EnterAmount.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.EnterAmount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EnterAmount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.EnterAmount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.EnterAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EnterAmount.ForeColor = System.Drawing.Color.Black;
            this.EnterAmount.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.EnterAmount.Location = new System.Drawing.Point(216, 59);
            this.EnterAmount.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.EnterAmount.Name = "EnterAmount";
            this.EnterAmount.PasswordChar = '\0';
            this.EnterAmount.PlaceholderForeColor = System.Drawing.Color.Black;
            this.EnterAmount.PlaceholderText = "";
            this.EnterAmount.ReadOnly = true;
            this.EnterAmount.SelectedText = "";
            this.EnterAmount.Size = new System.Drawing.Size(260, 38);
            this.EnterAmount.TabIndex = 219;
            this.EnterAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(193, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 20);
            this.label3.TabIndex = 225;
            this.label3.Text = "Teller";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(193, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 224;
            this.label2.Text = "Automated";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(74, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 26);
            this.label7.TabIndex = 223;
            this.label7.Text = "CHELLE\'S";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 222;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(191, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 226;
            this.label4.Text = "Machine";
            // 
            // CashWithdrawal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(914, 570);
            this.Controls.Add(this.Back);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CashWithdrawal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cash Withdrawal";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton Back;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton zero;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton nine;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton one;
        private System.Windows.Forms.GroupBox groupBox1;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton eight;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton Withdraw;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton seven;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton clear;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton six;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton two;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton five;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton three;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton four;
        private System.Windows.Forms.Label label1;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox EnterAmount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label4;
    }
}