﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atms
{
    public partial class DepositForm : Form
    {
        public DepositForm()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            this.Hide();
            MenuForm main = new MenuForm();
            main.Show();
        }

        private void clear_Click(object sender, EventArgs e)
        {
            EnterAmount.Clear();
        }

        private void Continue_Click(object sender, EventArgs e)
        {
            string c = EnterAmount.Text;
            GlobalVariable.withdraw_1 = EnterAmount.Text;


            this.Hide();
            ReceiptDeposit main = new ReceiptDeposit();
            main.Show();
        }

        private void one_Click(object sender, EventArgs e)
        {
            int number = 1;
            EnterAmount.Text += number;
        }

        private void two_Click(object sender, EventArgs e)
        {
            int number = 2;
            EnterAmount.Text += number;
        }

        private void three_Click(object sender, EventArgs e)
        {
            int number = 3;
            EnterAmount.Text += number;
        }

        private void four_Click(object sender, EventArgs e)
        {
            int number = 4;
            EnterAmount.Text += number;
        }

        private void five_Click(object sender, EventArgs e)
        {
            int number = 5;
            EnterAmount.Text += number;
        }

        private void six_Click(object sender, EventArgs e)
        {
            int number = 6;
            EnterAmount.Text += number;
        }

        private void seven_Click(object sender, EventArgs e)
        {
            int number = 7;
            EnterAmount.Text += number;
        }

        private void eight_Click(object sender, EventArgs e)
        {
            int number = 8;
            EnterAmount.Text += number;
        }

        private void nine_Click(object sender, EventArgs e)
        {
            int number = 9;
            EnterAmount.Text += number;
        }

        private void zero_Click(object sender, EventArgs e)
        {
            int number = 0;
            EnterAmount.Text += number;
        }
    }
}
