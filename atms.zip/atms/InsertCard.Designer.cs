﻿namespace atms
{
    partial class InsertCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InsertCard));
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.HScrollBar = new Siticone.Desktop.UI.WinForms.SiticoneHScrollBar();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.zero = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.nine = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.one = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.eight = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.enter = new Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton();
            this.seven = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.clear = new Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton();
            this.six = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.two = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.five = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.three = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.four = new Siticone.Desktop.UI.WinForms.SiticoneGradientButton();
            this.label1 = new System.Windows.Forms.Label();
            this.CardPin = new Siticone.Desktop.UI.WinForms.SiticoneTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(332, 362);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 16);
            this.label5.TabIndex = 151;
            this.label5.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(317, 362);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 150;
            this.label6.Text = "SWIPED";
            this.label6.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(109, 273);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(192, 16);
            this.label8.TabIndex = 149;
            this.label8.Text = "SWIPE YOUR CARD HERE: ";
            // 
            // HScrollBar
            // 
            this.HScrollBar.BorderRadius = 10;
            this.HScrollBar.InUpdate = false;
            this.HScrollBar.LargeChange = 10;
            this.HScrollBar.Location = new System.Drawing.Point(30, 312);
            this.HScrollBar.Name = "HScrollBar";
            this.HScrollBar.ScrollbarSize = 30;
            this.HScrollBar.Size = new System.Drawing.Size(355, 30);
            this.HScrollBar.TabIndex = 148;
            this.HScrollBar.ThumbColor = System.Drawing.SystemColors.ControlDarkDark;
            this.HScrollBar.Value = 1;
            this.HScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.HScrollBar_Scroll);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.zero);
            this.groupBox1.Controls.Add(this.nine);
            this.groupBox1.Controls.Add(this.one);
            this.groupBox1.Controls.Add(this.eight);
            this.groupBox1.Controls.Add(this.enter);
            this.groupBox1.Controls.Add(this.seven);
            this.groupBox1.Controls.Add(this.clear);
            this.groupBox1.Controls.Add(this.six);
            this.groupBox1.Controls.Add(this.two);
            this.groupBox1.Controls.Add(this.five);
            this.groupBox1.Controls.Add(this.three);
            this.groupBox1.Controls.Add(this.four);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.CardPin);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(401, 140);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(469, 387);
            this.groupBox1.TabIndex = 147;
            this.groupBox1.TabStop = false;
            // 
            // zero
            // 
            this.zero.Animated = true;
            this.zero.BackColor = System.Drawing.Color.Transparent;
            this.zero.BorderRadius = 20;
            this.zero.BorderThickness = 2;
            this.zero.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.zero.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.zero.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.zero.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.zero.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.zero.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.zero.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.zero.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.zero.ForeColor = System.Drawing.Color.Black;
            this.zero.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.zero.Location = new System.Drawing.Point(207, 310);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(70, 45);
            this.zero.TabIndex = 216;
            this.zero.Text = "0";
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // nine
            // 
            this.nine.Animated = true;
            this.nine.BackColor = System.Drawing.Color.Transparent;
            this.nine.BorderRadius = 20;
            this.nine.BorderThickness = 2;
            this.nine.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.nine.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.nine.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.nine.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.nine.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.nine.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.nine.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.nine.ForeColor = System.Drawing.Color.Black;
            this.nine.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.nine.Location = new System.Drawing.Point(303, 259);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(70, 45);
            this.nine.TabIndex = 215;
            this.nine.Text = "9";
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // one
            // 
            this.one.Animated = true;
            this.one.BackColor = System.Drawing.Color.Transparent;
            this.one.BorderRadius = 20;
            this.one.BorderThickness = 2;
            this.one.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.one.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.one.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.one.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.one.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.one.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.one.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.one.ForeColor = System.Drawing.Color.Black;
            this.one.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.one.Location = new System.Drawing.Point(107, 157);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(70, 45);
            this.one.TabIndex = 207;
            this.one.Text = "1";
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // eight
            // 
            this.eight.Animated = true;
            this.eight.BackColor = System.Drawing.Color.Transparent;
            this.eight.BorderRadius = 20;
            this.eight.BorderThickness = 2;
            this.eight.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.eight.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.eight.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.eight.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.eight.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.eight.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.eight.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.eight.ForeColor = System.Drawing.Color.Black;
            this.eight.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.eight.Location = new System.Drawing.Point(207, 259);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(70, 45);
            this.eight.TabIndex = 214;
            this.eight.Text = "8";
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // enter
            // 
            this.enter.BackColor = System.Drawing.Color.Transparent;
            this.enter.BorderRadius = 8;
            this.enter.BorderThickness = 2;
            this.enter.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.enter.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.enter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.enter.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.enter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.enter.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.enter.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(15)))), ((int)(((byte)(255)))));
            this.enter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.enter.ForeColor = System.Drawing.Color.White;
            this.enter.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.enter.Location = new System.Drawing.Point(303, 321);
            this.enter.Name = "enter";
            this.enter.Size = new System.Drawing.Size(108, 39);
            this.enter.TabIndex = 205;
            this.enter.Text = "ENTER";
            this.enter.UseTransparentBackground = true;
            this.enter.Click += new System.EventHandler(this.enter_Click);
            // 
            // seven
            // 
            this.seven.Animated = true;
            this.seven.BackColor = System.Drawing.Color.Transparent;
            this.seven.BorderRadius = 20;
            this.seven.BorderThickness = 2;
            this.seven.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.seven.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.seven.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.seven.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.seven.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.seven.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.seven.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.seven.ForeColor = System.Drawing.Color.Black;
            this.seven.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.seven.Location = new System.Drawing.Point(107, 259);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(70, 45);
            this.seven.TabIndex = 213;
            this.seven.Text = "7";
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.Color.Transparent;
            this.clear.BorderRadius = 8;
            this.clear.BorderThickness = 2;
            this.clear.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.clear.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.clear.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clear.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.clear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.clear.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(7)))), ((int)(((byte)(101)))), ((int)(((byte)(133)))));
            this.clear.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(15)))), ((int)(((byte)(255)))));
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.clear.ForeColor = System.Drawing.Color.White;
            this.clear.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.clear.Location = new System.Drawing.Point(67, 321);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(110, 39);
            this.clear.TabIndex = 206;
            this.clear.Text = "CLEAR";
            this.clear.UseTransparentBackground = true;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // six
            // 
            this.six.Animated = true;
            this.six.BackColor = System.Drawing.Color.Transparent;
            this.six.BorderRadius = 20;
            this.six.BorderThickness = 2;
            this.six.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.six.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.six.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.six.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.six.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.six.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.six.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.six.ForeColor = System.Drawing.Color.Black;
            this.six.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.six.Location = new System.Drawing.Point(303, 208);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(70, 45);
            this.six.TabIndex = 212;
            this.six.Text = "6";
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // two
            // 
            this.two.Animated = true;
            this.two.BackColor = System.Drawing.Color.Transparent;
            this.two.BorderRadius = 20;
            this.two.BorderThickness = 2;
            this.two.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.two.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.two.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.two.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.two.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.two.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.two.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.two.ForeColor = System.Drawing.Color.Black;
            this.two.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.two.Location = new System.Drawing.Point(207, 157);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(70, 45);
            this.two.TabIndex = 208;
            this.two.Text = "2";
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // five
            // 
            this.five.Animated = true;
            this.five.BackColor = System.Drawing.Color.Transparent;
            this.five.BorderRadius = 20;
            this.five.BorderThickness = 2;
            this.five.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.five.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.five.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.five.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.five.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.five.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.five.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.five.ForeColor = System.Drawing.Color.Black;
            this.five.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.five.Location = new System.Drawing.Point(207, 208);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(70, 45);
            this.five.TabIndex = 211;
            this.five.Text = "5";
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // three
            // 
            this.three.Animated = true;
            this.three.BackColor = System.Drawing.Color.Transparent;
            this.three.BorderRadius = 20;
            this.three.BorderThickness = 2;
            this.three.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.three.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.three.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.three.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.three.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.three.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.three.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.three.ForeColor = System.Drawing.Color.Black;
            this.three.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.three.Location = new System.Drawing.Point(303, 157);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(70, 45);
            this.three.TabIndex = 209;
            this.three.Text = "3";
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // four
            // 
            this.four.Animated = true;
            this.four.BackColor = System.Drawing.Color.Transparent;
            this.four.BorderRadius = 20;
            this.four.BorderThickness = 2;
            this.four.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.four.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.four.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.four.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.four.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.four.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.four.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold);
            this.four.ForeColor = System.Drawing.Color.Black;
            this.four.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.four.Location = new System.Drawing.Point(107, 208);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(70, 45);
            this.four.TabIndex = 210;
            this.four.Text = "4";
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(116, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(234, 16);
            this.label1.TabIndex = 131;
            this.label1.Text = "PLEASE ENTER YOUR CARD PIN ";
            // 
            // CardPin
            // 
            this.CardPin.BorderRadius = 18;
            this.CardPin.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.CardPin.DefaultText = "";
            this.CardPin.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.CardPin.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.CardPin.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CardPin.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.CardPin.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CardPin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CardPin.ForeColor = System.Drawing.Color.Black;
            this.CardPin.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.CardPin.Location = new System.Drawing.Point(107, 77);
            this.CardPin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.CardPin.Name = "CardPin";
            this.CardPin.PasswordChar = '*';
            this.CardPin.PlaceholderForeColor = System.Drawing.Color.Black;
            this.CardPin.PlaceholderText = "";
            this.CardPin.ReadOnly = true;
            this.CardPin.SelectedText = "";
            this.CardPin.Size = new System.Drawing.Size(257, 38);
            this.CardPin.TabIndex = 130;
            this.CardPin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(191, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 156;
            this.label4.Text = "Machine";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(193, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 20);
            this.label3.TabIndex = 155;
            this.label3.Text = "Teller";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(193, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 154;
            this.label2.Text = "Automated";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(74, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 26);
            this.label7.TabIndex = 153;
            this.label7.Text = "CHELLE\'S";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 152;
            this.pictureBox1.TabStop = false;
            // 
            // InsertCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(914, 570);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.HScrollBar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InsertCard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "A";
            this.Load += new System.EventHandler(this.InsertCard_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private Siticone.Desktop.UI.WinForms.SiticoneHScrollBar HScrollBar;
        private System.Windows.Forms.GroupBox groupBox1;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton zero;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton nine;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton one;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton eight;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton enter;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton seven;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton clear;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton six;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton two;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton five;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton three;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientButton four;
        private System.Windows.Forms.Label label1;
        private Siticone.Desktop.UI.WinForms.SiticoneTextBox CardPin;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}