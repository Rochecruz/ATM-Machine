﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atms
{
    public partial class DeductingBalance : Form
    {
        public DeductingBalance()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value == 100)
            {

                timer1.Stop();

                string box_msg = "The process is Successful!";
                MessageBox.Show(box_msg, "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                GetCashCardReceipt f3 = new GetCashCardReceipt();
                this.Hide();
                f3.ShowDialog();
            }

            else
            {
                progressBar1.Value += 1;

                label1.Text = progressBar1.Value.ToString() + "%";
            }
        }

        private void DeductingBalance_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
