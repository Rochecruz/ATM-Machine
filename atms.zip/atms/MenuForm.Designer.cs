﻿namespace atms
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Balance = new Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton();
            this.Deposit = new Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton();
            this.CashWithdrawal = new Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Balance);
            this.groupBox1.Controls.Add(this.Deposit);
            this.groupBox1.Controls.Add(this.CashWithdrawal);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(151, 187);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(623, 299);
            this.groupBox1.TabIndex = 219;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PLEASE CHOOSE SERVICES";
            // 
            // Balance
            // 
            this.Balance.BackColor = System.Drawing.Color.Transparent;
            this.Balance.BorderRadius = 8;
            this.Balance.BorderThickness = 2;
            this.Balance.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Balance.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Balance.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Balance.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Balance.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Balance.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.Balance.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.Balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.Balance.ForeColor = System.Drawing.Color.White;
            this.Balance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.Balance.Location = new System.Drawing.Point(235, 189);
            this.Balance.Name = "Balance";
            this.Balance.Size = new System.Drawing.Size(152, 59);
            this.Balance.TabIndex = 210;
            this.Balance.Text = "BALANCE";
            this.Balance.UseTransparentBackground = true;
            this.Balance.Click += new System.EventHandler(this.Balance_Click);
            // 
            // Deposit
            // 
            this.Deposit.BackColor = System.Drawing.Color.Transparent;
            this.Deposit.BorderRadius = 8;
            this.Deposit.BorderThickness = 2;
            this.Deposit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Deposit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Deposit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Deposit.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Deposit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Deposit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.Deposit.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.Deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.Deposit.ForeColor = System.Drawing.Color.White;
            this.Deposit.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.Deposit.Location = new System.Drawing.Point(354, 92);
            this.Deposit.Name = "Deposit";
            this.Deposit.Size = new System.Drawing.Size(152, 59);
            this.Deposit.TabIndex = 208;
            this.Deposit.Text = "DEPOSIT";
            this.Deposit.UseTransparentBackground = true;
            this.Deposit.Click += new System.EventHandler(this.Deposit_Click);
            // 
            // CashWithdrawal
            // 
            this.CashWithdrawal.BackColor = System.Drawing.Color.Transparent;
            this.CashWithdrawal.BorderRadius = 8;
            this.CashWithdrawal.BorderThickness = 2;
            this.CashWithdrawal.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.CashWithdrawal.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.CashWithdrawal.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.CashWithdrawal.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.CashWithdrawal.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.CashWithdrawal.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(110)))), ((int)(((byte)(127)))));
            this.CashWithdrawal.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(111)))), ((int)(((byte)(164)))));
            this.CashWithdrawal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            this.CashWithdrawal.ForeColor = System.Drawing.Color.White;
            this.CashWithdrawal.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.CashWithdrawal.Location = new System.Drawing.Point(113, 92);
            this.CashWithdrawal.Name = "CashWithdrawal";
            this.CashWithdrawal.Size = new System.Drawing.Size(152, 59);
            this.CashWithdrawal.TabIndex = 207;
            this.CashWithdrawal.Text = "WITHDRAW CASH";
            this.CashWithdrawal.UseTransparentBackground = true;
            this.CashWithdrawal.Click += new System.EventHandler(this.CashWithdrawal_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(191, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 218;
            this.label4.Text = "Machine";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(193, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 20);
            this.label3.TabIndex = 217;
            this.label3.Text = "Teller";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(193, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 216;
            this.label2.Text = "Automated";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(74, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 26);
            this.label7.TabIndex = 215;
            this.label7.Text = "CHELLE\'S";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImageLocation = "";
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 214;
            this.pictureBox1.TabStop = false;
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(914, 570);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MenuForm";
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton Balance;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton Deposit;
        private Siticone.Desktop.UI.WinForms.SiticoneGradientTileButton CashWithdrawal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}